// Dashboard.js
import React from 'react';
import { Routes, Route, Link, Outlet } from 'react-router-dom';
import Sidebar from './Sidebar'

function Dashboard() {
  return (
    <>
    <Sidebar/>
    </>
   
  );
}


export default Dashboard;
